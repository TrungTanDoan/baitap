package com.example.choosecolor;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar seekR, seekG, seekB;
    TextView txtR, txtG, txtB;
    FrameLayout viewRGB, viewCMY;

    int r = 0, g = 0, b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Gán ID
        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);

        txtR = findViewById(R.id.txtR);
        txtG = findViewById(R.id.txtG);
        txtB = findViewById(R.id.txtB);

        viewRGB = findViewById(R.id.viewRGB);
        viewCMY = findViewById(R.id.viewCMY);

        // Lắng nghe thay đổi Seekbar
        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);

        updateColor();
    }

    SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            if (seekBar == seekR) r = progress;
            if (seekBar == seekG) g = progress;
            if (seekBar == seekB) b = progress;

            txtR.setText("R = " + r);
            txtG.setText("G = " + g);
            txtB.setText("B = " + b);

            updateColor();
        }

        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    };

    // Cập nhật màu RGB và CMY
    private void updateColor() {
        // Màu RGB
        viewRGB.setBackgroundColor(Color.rgb(r, g, b));

        // CMY = màu bù của RGB
        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;

        viewCMY.setBackgroundColor(Color.rgb(c, m, y));
    }
}
