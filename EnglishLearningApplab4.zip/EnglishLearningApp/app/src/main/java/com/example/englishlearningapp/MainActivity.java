package com.example.englishlearningapp;

import android.content.Intent; // ⚠️ Bổ sung import này
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int[] ID_DRAWABLES = {
            R.drawable.ic_mess, R.drawable.ic_flight, R.drawable.ic_hospital,
            R.drawable.ic_hotel, R.drawable.ic_restaurant, R.drawable.ic_coctail,
            R.drawable.ic_store, R.drawable.ic_at_work, R.drawable.ic_time,
            R.drawable.ic_education, R.drawable.ic_movie
    };

    private static final int[] ID_TEXTS = {
            R.string.txt_mess, R.string.txt_flight, R.string.txt_hospital,
            R.string.txt_hotel, R.string.txt_restaurant, R.string.txt_coctail,
            R.string.txt_store, R.string.txt_work, R.string.txt_time,
            R.string.txt_education, R.string.txt_movie
    };

    private static final String[][] VOCABULARY = {
            {"Hello", "Goodbye", "Thank you", "Sorry"},
            {"Airport", "Ticket", "Luggage", "Passport"},
            {"Doctor", "Nurse", "Hospital", "Medicine"},
            {"Reception", "Room", "Key", "Check out"},
            {"Menu", "Dish", "Fork", "Bill"},
            {"Beer", "Wine", "Bar", "Cheers"},
            {"Shop", "Money", "Price", "Discount"},
            {"Office", "Manager", "Meeting", "Project"},
            {"Day", "Month", "Year", "Clock"},
            {"Teacher", "Student", "Lesson", "Exam"},
            {"Movie", "Actor", "Screen", "Director"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        LinearLayout lnMain = findViewById(R.id.ln_main);
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 0; i < ID_DRAWABLES.length; i++) {
            View v = inflater.inflate(R.layout.item_topic, lnMain, false);

            ImageView iv = v.findViewById(R.id.iv_topic);
            TextView tv = v.findViewById(R.id.tv_topic);

            iv.setImageResource(ID_DRAWABLES[i]);
            tv.setText(ID_TEXTS[i]);

            int index = i; // final để dùng trong lambda

            v.setOnClickListener(view -> {
                // Hiển thị Toast trước (tùy chọn)
                StringBuilder sb = new StringBuilder();
                for (String word : VOCABULARY[index]) {
                    sb.append(word).append(", ");
                }
                Toast.makeText(this, "Từ vựng: " + sb.toString(), Toast.LENGTH_SHORT).show();

                // Sau đó mở Activity mới
                Intent intent = new Intent(MainActivity.this, VocabularyActivity.class);
                intent.putExtra("topic_name", getString(ID_TEXTS[index]));
                intent.putExtra("vocab_list", VOCABULARY[index]);
                startActivity(intent);
            });

            lnMain.addView(v);
        }
    }
}
