package com.example.englishlearningapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class VocabularyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary);

        TextView tvTopicName = findViewById(R.id.tv_topic_name);
        ListView lvWords = findViewById(R.id.lv_words);

        // Nhận dữ liệu từ Intent
        String topicName = getIntent().getStringExtra("topic_name");
        String[] words = getIntent().getStringArrayExtra("vocab_list");

        tvTopicName.setText(topicName);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, words
        );
        lvWords.setAdapter(adapter);
    }
}
